package ds.project1.project1task2;

/*
 * @author: Shivani Poovaiah Ajjikutira
 * Last modified: 25 September 2021
 *
 * This project is a web application which displays the GDP, population, olympic medals
 * and flags of 20 largest countries by GDP by scrapping 3 websites. The application follows
 * MVC architecture. CountryServlet is the Controller, CountryModel is the Model and the two
 * Views are index.jsp and result.jsp. The user selects the country on the index.jsp using a
 * dropdown and submits the form. The servlet then passes the country name to the Model to
 * scrape the required data from the 3 websites. The scrapping logic is written in the Model.
 * The Model returns the data to the Controller which then sets attributes for each of the
 * datasets and passes Control to the view.
 * */
import java.io.*;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

/*
 * The WebServlet annotation given below provides instructions to the web container.
 * It states that when the user browses to the URL path /getCountryData then the servlet
 * with the name countryServlet should be used.
 * */
@WebServlet(name = "countryServlet",  urlPatterns = {"/getCountryData"})
public class CountryServlet extends HttpServlet {

    CountryModel cgm = null; // Model for the web application

    // The servlet initializes by instantiating an object of the Model
    public void init() {
        cgm = new CountryModel();
    }

    // The servlet replies to the HTTP GET requests using this doGet method
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        // get country parameter if exists
        String countrySelected = request.getParameter("country");
        // set countryName attribute
        request.setAttribute("countryName", countrySelected);

        // Code referred from Lab2
        String nextView;
        String [] countryData;
        /*
        * If country parameter exists and is not null then fetch required data
        * from Model using cgm object by passing the country name as an argument
        * to the doCountrySearch method of Model. The Model scrapes the websites
        * and returns an array containing all required data which is stored in
        * countryData array. If the array is not null then set all attributes
        * respectively using data at specific array indexes in countryData array.
        * The NullPointerException is handled using try catch block in case Model
        * returns a null array.
        * */
        if(countrySelected!= null) {
            countryData = cgm.doCountrySearch(countrySelected);
            if (countryData != null) {
                request.setAttribute("countryData", countryData);
                request.setAttribute("gdp", countryData[0]);
                request.setAttribute("population", countryData[1]);
                request.setAttribute("gold", countryData[2]);
                request.setAttribute("silver", countryData[3]);
                request.setAttribute("bronze", countryData[4]);
                request.setAttribute("totalMedals", countryData[5]);
                request.setAttribute("expectedCount", countryData[6]);
                request.setAttribute("flagUrl", countryData[7]);
            }
            // country parameter exists so choose the result.jsp view
            nextView = "result.jsp";
        } else {
            // no country parameter so choose the index.jsp view
            nextView = "index.jsp";
        }
        // Transfer control to correct View
        RequestDispatcher view = request.getRequestDispatcher(nextView);
        view.forward(request, response);
    }
}
