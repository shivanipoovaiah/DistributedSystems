package ds.project1.project1task2;

/*
 * @author: Shivani Poovaiah Ajjikutira
 * Last Modified: 25 September 2021
 *
 * This is the Model for the web application and scrapes the 3 websites
 * based on the country name sent by the Controller(servlet). Java Jsoup library
 * is used to fetch and traverse through the HTML of the 3 websites. The urls of
 * the 3 websites are used to get the HTML using the Jsoup get method. Contents of
 * element tree are then checked to find the country selected. The required data
 * corresponding to the country is then extracted and sent back to the Controller
 * as an array
 * */
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;

public class CountryModel {
    /*
    * This method passes the country name to the methods scrapping the data from
    * the 3 sites and passes an array containing all necessary information back
    * to the Controller
    * */
    public String[] doCountrySearch(String searchCountry) throws IOException{
        // gets gdp and population
        String [] gdpAndPopulation = getGDPAndPopulation(searchCountry);
        String gdp = gdpAndPopulation[0];
        String population = gdpAndPopulation[1];

        // gets medal count
        String [] medals = getMedals(searchCountry);
        String gold = medals[0];
        String silver = medals[1];
        String bronze = medals[2];
        String totalMedals = medals[3];

        // gets estimated medal count
        String estimatedMedals = calculateEstimatedMedals(gdp,population);
        // gets country flag
        String gifUrl = getCountryFlag(searchCountry);

        // return data to Controller
        return new String [] { gdp, population, gold, silver, bronze,
                totalMedals, estimatedMedals, gifUrl};
    }

    /*
    * This method uses jsoup to parse the html from the GDP url provided. The
    * element nodes are traversed to find the country name. After finding the
    * correct node, the gdp and population data is stored in an array and returned.
    * */
    public String[] getGDPAndPopulation(String searchCountry) throws IOException {
        // gets html from the url
        Document doc = Jsoup.connect("https://www.worldometers.info/gdp/" +
                "gdp-by-country/").get();
        // finds table with id "example2" in element tree
        Element table = doc.getElementById("example2");
        if (table != null) {
            // gets all table rows
            Elements rows = table.getElementsByTag("tr");
            // loops through rows and find data cell containing country name
            for (Element row : rows) {
                // gets all data cells
                Elements dataCells = row.getElementsByTag("td");
                if (dataCells.size() != 0) {
                    Element country = dataCells.get(1).child(0);
                    // if text in element equals searchCountry returns array
                    // with data
                    if (country.text().equalsIgnoreCase(searchCountry)) {
                        String [] data = new String[2];
                        // stores gdp
                        data[0] = dataCells.get(2).text();
                        // stores population
                        data[1] = dataCells.get(5).text();
                        return data;
                    }
                }
            }
        }
        return null;
    }

    /*
     * This method uses jsoup to parse the html from the Tokyo Olympics url
     * provided. The search attribute is modified for 3 countries as they
     * have different naming convention on this website in comparison to the
     * searchCountry string. The element nodes are traversed to find the country
     * name. After finding the correct node, the medal data is stored in an
     * medals array and returned.
     * */
    public String[] getMedals(String searchCountry) throws IOException{
        // replaces country name for countries having different naming convention
        if(searchCountry.equalsIgnoreCase("United Kingdom")) {
            searchCountry = "Great Britain";
        }  else if(searchCountry.equalsIgnoreCase("Russia")) {
            searchCountry = "ROC";
        } else  if(searchCountry.equalsIgnoreCase("South Korea")) {
            searchCountry = "Republic of Korea";
        }

        // gets html from the url
        Document doc = Jsoup.connect("https://olympics.com/tokyo-2020/olympic-games/en/results/" +
                "all-sports/medal-standings.htm").get();
        // finds table with id "medal-standing-table" in element tree
        Element table = doc.getElementById("medal-standing-table");
        if(table != null) {
           // gets all table rows
            Elements rows = table.getElementsByTag("tr");
            for (Element row : rows) {
                // gets all table data cells
                Elements dataCells = row.getElementsByTag("td");
                if (dataCells.size() != 0) {
                    // gets Country name
                    String country = dataCells.get(1).child(0).child(0).text();
                    // if country contains search country returns array with
                    // medal data
                    if (country.contains(searchCountry)) {
                        String [] medals = new String[4];
                        /*
                        * The array stores number of gold, silver, bronze and total medals.
                        * For loop is used to assign data to each index of medals array.
                        * The html template is designed such that countries with
                        * a positive medal count have an anchor tag inside the data cell
                        * which navigates users to another page. The countries having
                        * 0 medal count do not have this anchor tag. The ternary operator
                        * checks if the element has an anchor tag or not and assigns text
                        * to the medals array accordingly and returns it
                        * */
                        for(int i=0; i<medals.length; i++) {
                            medals[i] = dataCells.get(2+i).childrenSize() >= 1 ?
                                    dataCells.get(2+i).child(0).text() : dataCells.get(2+i).text();
                        }
                        return medals;
                    }
                }
        }
        }
        return null;
    }

    /*
    * This method calculates the estimated medal count using the gdp
    * and population using a formula mentioned in a book. The gdp
    * and population strings are first filtered so that they contain
    * only numerals, converted to double type and then the inserted
    * into the formula. Math module's pow method is used to find
    * power of numbers. The result is formatted to include two decimal
    * places post the decimal point and returned to the calling method
    * */
    public String calculateEstimatedMedals(String gdp, String population) {
        // removes $ and , in the gdp string
        String gdpNum = gdp.replaceAll("[$,]+","");
        // removes , in the population string
        String popNum = population.replaceAll(",","");
        double g = Double.parseDouble(gdpNum)/1000000000;
        double p = Double.parseDouble(popNum)/1000000;
        double estimate =  0.1*(Math.pow(p*(Math.pow(g,2)),(1.0/3.0)));
        return String.format("%.2f",estimate);
    }

    /*
     * This method uses jsoup to parse the html from the Commons Wikipedia url
     * provided. The element nodes are traversed to find the country
     * name. After finding the correct node, the image url is fetched from
     * the src attribute and returned.
     * */
    public String getCountryFlag(String searchCountry) throws IOException {
        // gets html from the url
        Document doc = Jsoup.connect("https://commons.wikimedia.org/wiki/Animated_GIF_flags").get();
        // gets all elements with class gallerybox
        Elements allFlags = doc.getElementsByAttributeValue("class","gallerybox");
        // loop through each gallery box element of every flag
        for(Element flag: allFlags) {
            // if children of flag node contains the country name
            if(flag.child(0).child(1).child(0).text().contains(searchCountry)) {
                // get the image tag from the child node
                Element image = flag.child(0).child(0).child(0).child(0).child(0);
                // return the value of attribute src in image tag
                return image.attr("src");

            }
        }
        return null;
    }
}
