package ds.project1.project1task1;

/*
 * @author: Shivani Poovaiah Ajjikutira
 * Last modified: 25 September 2021
 *
 * This task is an example for accepting a string from the user, hashing it
 * using either MD5 or SHA-256 hashing based on the user's choice and displaying
 * the hashed code encoded into Hexadecimal or Base65 encoding schemes. The MVC
 * architecture is used in design of this web application. The starting page of
 * the application is the index.jsp which is the View, ComputeHashes servlet is
 * the Controller and ComputeHashesModel is the Model. The user input is collected
 * from the View and passed to the Controller through a form submit. The Controller
 * passes the input string along with the hash function selected to the Model for
 * computation. All the hashing and encoding computations happen in the Model. Once
 * the hashing and encoding is completed, the Hexadecimal and Base64 encoded strings
 * are sent back to the Controller which then dispatches the output to the View.
 * */
import java.io.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

/*
* The WebServlet annotation given below provides instructions to the web container.
* It states that when the user browses to the URL path /getHash then the servlet
* with the name ComputeHashes should be used.
* */
@WebServlet(name = "ComputeHashes", urlPatterns = {"/getHash"})
public class ComputeHashes extends HttpServlet {

    ComputeHashesModel chm=null; // Model for the web application

    // The servlet initializes by instantiating an object of the Model
    public void init() {
        chm= new ComputeHashesModel();
    }

    // The servlet replies to the HTTP GET requests using this doGet method
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        // get the user input and hash type parameters if they exist
        String userInput = request.getParameter("userInputString");
        String hashType = request.getParameter("hashFunction");

        // if the user input, hash type parameters exist then compute hash and encoding
        if(userInput!=null && hashType!=null) {

            /*
            * Use computeHashAndEncoding method in the Model to compute hashing and encoding.
            * Method returns Hex and Base64 encoded strings in the same index order as an array.
            * */
            String[] encodings = chm.computeHashAndEncoding(userInput, hashType);
            /*
             * If encodings array is not null set the attributes on the request object.
             * Attributes are name-value pairs on the request object. Attributes are used
             * to pass data to the View. Here, hasEncodedStrings, userString, hash, hex
             * and base64 attributes are set.
             */
            if (encodings != null) {
                request.setAttribute("encodings", "hasEncodedStrings");
                request.setAttribute("userString", userInput);
                request.setAttribute("hash", hashType);
                request.setAttribute("hex", encodings[0]);
                request.setAttribute("base64", encodings[1]);
            }
            // Passes the control to the View, i.e, index.jsp
            request.getRequestDispatcher("index.jsp").forward(request,response);
        }
    }
}