package ds.project1.project1task1;

/*
* @author: Shivani Poovaiah Ajjikutira
* Last Modified: 25 September 2021
*
* This is the Model for the web application and computes the hash and encoding
* logic. The logic involves creating an object of MessageDigest class and using
* it to hash the user input string using the digest method. The method returns
* hashed bytes which is passed into the printHexBinary and printBase64Binary
* methods of DatatypeConverter class to convert the bytes into Hexadecimal
* and Base64 strings respectively.
* */
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class ComputeHashesModel {

    // method returns array containing encoded strings. If exception is encountered returns null
    public String [] computeHashAndEncoding(String userInput, String hashType) {
        try {
            // code from Lab1 and Project1 instructions
            MessageDigest md = MessageDigest.getInstance(hashType);
            md.update(userInput.getBytes());
            String updatedHexString = jakarta.xml.bind.DatatypeConverter.printHexBinary(md.digest());
            String updatedBase_64_String = jakarta.xml.bind.DatatypeConverter.printBase64Binary(md.digest());
            // returns String array containing hex and base64 encoded strings.
            return new String[] {updatedHexString,updatedBase_64_String};
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }
}
