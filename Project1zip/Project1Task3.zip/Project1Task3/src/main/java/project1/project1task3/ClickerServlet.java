package project1.project1task3;

/*
 * @author: Shivani Poovaiah Ajjikutira
 * Last modified: 25 September 2021
 *
 * This project is a web application which implements a Clicker.
 * The application uses MVC architecture. The ClickerServlet is the
 * Controller, ClickerModel is the Model and there are two Views -
 * index.jsp and result.jsp. The user clicks on one option and submits 
 * the form using HTTP post request to the Controller. Each time the user 
 * submits the choice, the option selected by him is stored and displayed 
 * on the index.jsp View for the /submit url pattern. The number of clicks 
 * made by the user for each option is counted and stored in the Model. This 
 * data is passed to the Controller which passes the control to the view depending 
 * on the url pattern. On opening the /getResults url the number of clicks for 
 * each option is displayed. If the user did not make any click no requests 
 * message is displayed.
 * */

import java.io.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;


/*
 * The WebServlet annotation given below provides instructions to the web container.
 * It states that when the user browses to the URL path /submit and getResults then
 * the servlet with the name countryServlet should be used.
 * */
@WebServlet(name = "clickerServlet", urlPatterns = {"/submit", "/getResults"})
public class ClickerServlet extends HttpServlet {

    ClickerModel sm; // Model for the web application

    // The servlet initializes by instantiating an object of the Model
    public void init() {
        sm = new ClickerModel();
    }

    // The servlet replies to the HTTP GET requests using this doGet method
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        // sets docType based on device
        setDocType(request);
        // gets option selection count in the form of an array from Model
        int [] tally = ClickerModel.tally;
        /*
        * If tally is not null, loop through tally array and check if
        * items on the array are equal to 0. If yes increment. If all
        * items are 0 then noSelection is equal to 4. If so, set attribute
        * tally "to noSelection" else set it to "selected". Also, if all
        * four are not 0, set attributes aCount, bCount, cCount, dCount
        * respectively from tally array.
        * */
        if(tally!= null) {
            int noSelection=0;
            for(int i=0; i<tally.length; i ++) {
                if(tally[i] == 0) {
                    noSelection++;
                }
            }
            request.setAttribute("tally","noSelection");
            if(noSelection != 4) {
                request.setAttribute("tally","selected");
                request.setAttribute("aCount", tally[0]);
                request.setAttribute("bCount", tally[1]);
                request.setAttribute("cCount", tally[2]);
                request.setAttribute("dCount", tally[3]);
            } else {
                request.setAttribute("tally","noSelection");
            }
        } else {
            request.setAttribute("tally", "noSelection");
        }
        // if url pattern is /submit pass the control to index.jsp View
        if(request.getServletPath().equals("/submit")) {
            request.getRequestDispatcher("index.jsp").forward(request,response);
        } else {  // pass the control to result.jsp View
            request.getRequestDispatcher("result.jsp").forward(request,response);
            sm = new ClickerModel();
        }

    }

    // This method sets docType based on the device used to access the website
    private void setDocType(HttpServletRequest request) {
        // Code from Lab2
        String ua = request.getHeader("User-Agent");
        // prepare the appropriate DOCTYPE for the view pages
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            /*
             * This is the latest XHTML Mobile doctype. To see the difference it
             * makes, comment it out so that a default desktop doctype is used
             * and view on an Android or iPhone.
             */
            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        }
    }

    // The servlet replies to the HTTP POST requests using this doPost method
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // sets docType based on device
        setDocType(request);
        String input = request.getParameter("section");
        sm.setSectionCount(input);
        request.setAttribute("selected",input);
        if(request.getServletPath().equals("/submit")) {
            request.getRequestDispatcher("index.jsp").forward(request,response);
        }
    }
}