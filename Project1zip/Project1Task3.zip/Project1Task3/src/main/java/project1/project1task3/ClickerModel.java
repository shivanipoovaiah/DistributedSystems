package project1.project1task3;

/*
 * @author: Shivani Poovaiah Ajjikutira
 * Last Modified: 25 September 2021
 *
 * This is the Model for the web application. The controller passes
 * the selected option to the setSectionCount method. The constructor
 * initializes the tally array. This method checks the String passed using
 * a switch case and updates the data in corresponding index. The static
 * array enables to call the array using the Class name directly and does
 * not need to instantiate a new object.
 * */
public class ClickerModel {

    static int [] tally;

    // constructor to initialize tally array
    public ClickerModel() {
        tally = new int[4];
    }

    // update count after switch case check
    public void setSectionCount(String selected) {
        switch (selected) {
            case "A":
                tally[0] += 1;
                break;
            case "B":
                tally[1] += 1;
                break;
            case "C":
                tally[2] += 1;
                break;
            default:
                tally[3] += 1;
                break;
        }
    }
}
