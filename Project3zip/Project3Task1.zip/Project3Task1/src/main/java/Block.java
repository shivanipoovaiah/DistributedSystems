/*
 * @author: Shivani Poovaiah Ajjikutira
 * Last Modified: 24th October 2021
 *
 * Explanation and code taken from JavaDoc -
 * https://www.andrew.cmu.edu/course/95-702/examples/javadoc/blockchaintask0/Block.html#getNonce()
 * This class represents a simple Block.
 * Each Block object has an index - the position of the block on the chain.
 * The first block (the so-called Genesis block) has an index of 0.
 * Each block has a timestamp - a Java Timestamp object, it holds the time of the block's creation.
 * Each block has a field named data - a String holding the block's single transaction details.
 * Each block has a String field named previousHash - the SHA256 hash of a block's parent.
 * This is also called a hash pointer.
 * Each block holds a nonce - a BigInteger value determined by a proof of work routine.
 * This has to be found by the proof of work logic. It has to be found so that this block has a
 * hash of the proper difficulty. The difficulty is specified by a small integer representing the
 * minimum number of leading hex zeroes the hash must have.
 * Each block has a field named difficulty - it is an int that specifies the minimum number of left
 * most hex digits needed by a proper hash. The hash is represented in hexadecimal.
 * If, for example, the difficulty is 3, the hash must have at least three leading hex 0's
 * (or,1 and 1/2 bytes). Each hex digit represents 4 bits.
 * */

import org.json.simple.JSONObject;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;

public class Block {
    private int index;
    private Timestamp timestamp;
    private String data;
    private int difficulty;
    private BigInteger nonce;
    private String previousHash;

    /* constructor:
    index - This is the position within the chain. Genesis is at 0.
    timestamp - This is the time this block was added.
    data - This is the transaction to be included on the blockchain.
    difficulty - This is the number of leftmost nibbles that need to be 0.
    nonce - The nonce is a number that has been found to cause the hash of this block to have the
     correct number of leading hexadecimal zeroes.
     */
    Block (int index, Timestamp timestamp, String data, int difficulty){
        this.index=index;
        this.timestamp = timestamp;
        this.data= data;
        this.difficulty=difficulty;
        this.nonce = new BigInteger("0");
    }

    public static void main (String[] args) {}

    // This method computes a hash of the concatenation of the index,
    // timestamp, data, previousHash, nonce, and difficulty.
    public String calculateHashes(){
        String block = index+String.valueOf(timestamp)+data+previousHash+nonce+difficulty;
        byte[] bytesOfBlock = block.getBytes(StandardCharsets.UTF_8);
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedOutput = md.digest(bytesOfBlock);
            return bytesToHex(hashedOutput);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return block;
    }

    // Code from https://stackoverflow.com/questions/9655181/how-to-convert-a-byte-array-to-a-hex-string-in-java
    private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars);
    }

    // getter for nonce
    public BigInteger getNonce() {
        return this.nonce;
    }

    // setter for nonce
    public void setNonce(BigInteger nonce) {
        this.nonce=nonce;
    }

    // The proof of work methods finds a good hash, i.e, the number of zeroes in the
    // start of hash must be equal to difficulty of the block
    public String proofOfWork() {
        String hashReturned = "";
        boolean proofOfWorkPass = false;
        while(!proofOfWorkPass) {
            hashReturned = calculateHashes();
            char[] charsHash = hashReturned.toCharArray();
            int difficulty = getDifficulty();
            int numberOfZero = 0;
            // count zeroes
            for (int i = 0; i < difficulty; i++) {
                if (charsHash[i] == '0') {
                    numberOfZero++;
                }
            }
            if (numberOfZero == difficulty) proofOfWorkPass = true;
            else setNonce(getNonce().add(BigInteger.valueOf(1)));
        }
        return hashReturned;
    }

    // getter for difficulty
    public int getDifficulty() {
        return this.difficulty;
    }

    // setter for difficulty
    public void setDifficulty (int difficulty) {
        this.difficulty = difficulty;
    }

    // toString method of individual block to form string in json format
    public String toString() {
        JSONObject jsonBlock = new JSONObject();
        jsonBlock.put("index",index);
        jsonBlock.put("time stamp",String.valueOf(timestamp));
        jsonBlock.put("Tx ",data);
        jsonBlock.put("PrevHash",previousHash);
        jsonBlock.put("nonce",nonce);
        jsonBlock.put("difficulty",difficulty);
        return jsonBlock.toString();
    }

    // setter for previous hash
    public void setPreviousHash(String previousHash) {
        this.previousHash = previousHash;
    }
    // getter for previous hash
    public String getPreviousHash() {
        return this.previousHash;
    }
    // getter for index
    public int getIndex() {
        return this.index;
    }

    // setter for index
    public void setIndex (int index) {
        this.index =index;
    }

    // setter for timestamp
    public void setTimestamp (Timestamp timestamp) {
        this.timestamp= timestamp;
    }

    // getter for timestamp
    public Timestamp getTimestamp() {
        return this.timestamp;
    }

    // getter for data/transaction
    public String getData() {
        return this.data;
    }

    // setter for data/transaction
    public void setData (String data) {
        this.data = data;
    }
}
