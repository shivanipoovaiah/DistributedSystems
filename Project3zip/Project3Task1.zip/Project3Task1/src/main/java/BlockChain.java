/*
 * @author: Shivani Poovaiah Ajjikutira
 * Last Modified: 24th October 2021
 *
 * This code follows Task 0 but uses TCP for the data transmission between the client
 * and server. The following code is the server side for the program.
 * The server socket is initialized and continues to listen to any
 * request sent by client sockets connected to port number 7777.The server
 * receives the data from the client through Scanner "in" via the socket connection
 * formed. The PrintWriter "out" is used to write into the stream and send data
 * back to the requesting client. The performOperations method checks the operation
 * passed and does the required logic on the blockchain.The server is always running.
 * Explanation and code taken from JavaDoc -
 * https://www.andrew.cmu.edu/course/95-702/examples/javadoc/blockchaintask0/BlockChain.html#isChainValid()
 * This is the code for Blockchain. It will begin by creating a BlockChain object
 * and then adding the Genesis block to the chain. The Genesis block will be created with an empty string
 * as the previous hash and a difficulty of 2. On start up, this code will also establish the hashes per
 * second instance member. All blocks added to the Blockchain will have a difficulty passed by the
 * client. All hashes will have the proper number of zero hex digits representing
 * the most significant nibbles in the hash. A nibble is 4 bits. If the difficulty is specified as three,
 * then all hashes will begin with 3 or more zero hex digits (or 3 nibbles, or 12 zero bits).
 * It is menu-driven and based on the user selection, different data is sent from the client and
 * certain operations are performed on the blockchain on the server side.
 * */

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import com.google.gson.*;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.*;

public class BlockChain {
    // ArrayList to hold Blocks
    private final ArrayList<Block> blocks;
    // holds a SHA256 hash of the most recently added Block.
    private String chainHash;
    // Store hashes per second
    private static int hashesPerSecond;
    // store node having wrong hash
    private int incorrectNode;

    // constructor
    BlockChain() {
        // initialize blocks ArrayList, chainHash and hashesPerSecond
        blocks= new ArrayList<>();
        chainHash = "";
        hashesPerSecond=0;
    }

    /*
     * On startup the genesis block is created and added to the blockchain. Based on the data
     * sent from the client different operations are performed in the performOperations method.
     *
     * Based on the experiments conducted the computation time increases as the difficulty associated
     * with the block increases. For instance, for difficulty 2, addBlock() methods takes between
     * 0-15 milliseconds approximately. For difficulty 5, addBlock() methods took 461 milliseconds
     * approximately. For difficulty 6, addBlock() methods took 6000 milliseconds approximately.
     * The repairChain() and isChainValid methods take approximately 0 milliseconds if all the blocks
     * have correct data irrespective of the difficulty of the blocks. However, in the presence of a
     * malicious block having corrupt data, repairChain() method takes longer time if there are blocks
     * with higher difficulty. For instance, if malicious block has a difficulty of 2, the
     * repairChain() method took 2775 milliseconds. But if malicious block has a difficulty of 6, the
     * repairChain() method took 13221 milliseconds. isChainValid() method also takes longer time
     * if malicious block has higher difficulty. For difficulty 2 of malicious block, isChainValid()
     * method took close to 0 milliseconds and for difficulty 6, method took close to 362 milliseconds.
     * */
    public static void main(String[] args){
        BlockChain blockChain = new BlockChain();
        Block genesisBlock = new Block(0, new Timestamp(new Date().getTime()), "Genesis", 2);
        genesisBlock.setPreviousHash("");
        blockChain.computeHashesPerSecond();
        blockChain.addBlock(genesisBlock);
        // Code from EchoServerTCP.java in Project 2
        System.out.println("Server started");
        // client socket declared
        Socket clientSocket = null;
        try{
            int serverPort = 7777; // the server port number

            // Create a new server socket with port number 7777
            ServerSocket listenSocket = new ServerSocket(serverPort);

            // Since server is always running and listens for requests
            while(true){
                /*
                 * Block waiting for a new connection request from a client.
                 * When the request is received, "accept" it, and the rest
                 * the tcp protocol handshake will then take place, making
                 * the socket ready for reading and writing.
                 */
                if(clientSocket==null || clientSocket.getInputStream().read() == -1)
                    clientSocket = listenSocket.accept();
                // If we get here, then we are now connected to a client.

                // Set up "in" to read from the client socket
                Scanner in;
                in = new Scanner(clientSocket.getInputStream());

                // Set up "out" to write to the client socket
                PrintWriter out;
                out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));
                // read from client socket
                String data = in.nextLine();
                // result stores JSON string returned by performOperations method
                String result = blockChain.performOperations(data);
                // write to client socket
                out.println(result);
                // send data written to client socket
                out.flush();
            }
        } catch (SocketException e) {
            // to catch errors when errors occur with the network
            System.out.println("Socket: " + e.getMessage());
        }catch (IOException e){
            // to catch errors when there is an input-output exception
            System.out.println("IO: " + e.getMessage());
        }
    }

    // check the proofOfWork for each block and add it to the blockchain, update
    // chain hash with the latest added block's proofOfWork
    public void addBlock (Block newBlock) {
        if(blocks.size()!=0) newBlock.setPreviousHash(getBlock(blocks.size()-1).proofOfWork());
        blocks.add(newBlock);
        chainHash = newBlock.proofOfWork();
    }

    // getter for timestamp
    public Timestamp getTime() {
        return new Timestamp(new Date().getTime());
    }

    // getter for latest block
    public Block getLatestBlock() {
        return getBlock(blocks.size()-1);
    }

    // getter for chain size
    public int getChainSize() {
        return blocks.size();
    }

    /*
     * This method computes exactly 1 million hashes and times how long that process takes.
     * So, hashes per second is approximated as (1 million / number of seconds). It is run on start
     * up and sets the instance variable hashesPerSecond. It uses a simple string -
     * "00000000" to hash.*/
    public void computeHashesPerSecond() {
        String sampleString = "00000000";
        long startTime = getTime().getTime();
        byte[] bytesOfHash = sampleString.getBytes(StandardCharsets.UTF_8);
        for(int i=0; i<1000000;i++) {
            try {
                // Use SHA-256 for hashing
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                md.digest(bytesOfHash);
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
        }
        long endTime = getTime().getTime();
        BlockChain.hashesPerSecond = (int) (1000000*1000/ (double) (endTime - startTime));
    }

    // getter for hashes per second
    public int getHashesPerSecond() {
        return hashesPerSecond;
    }

    // creates string in json format for entire blockchain using toString method of
    // individual blocks
    public String toString() {
        System.out.println("View the Blockchain");
        JSONArray jsonBlocks = new JSONArray();
        for(int i=0; i<blocks.size();i++) {
            Block block = getBlock(i);
            JsonElement jsonElement = new JsonParser().parse(block.toString());
            jsonBlocks.add(jsonElement);
        }
        JSONObject outputJson = new JSONObject();
        outputJson.put("ds_chain",jsonBlocks);
        outputJson.put("chainHash",chainHash);
        return outputJson.toString();
    }

    // getter for block at index i
    public Block getBlock (int i) {
        return blocks.get(i);
    }

    // compute and return the total difficulty of all blocks on the chain.
    public int getTotalDifficulty() {
        int totalDifficulty=0;
        for(int i=0; i< blocks.size(); i++) {
            totalDifficulty+=getBlock(i).getDifficulty();
        }
        return totalDifficulty;
    }

    // Compute and return the expected number of hashes required for the entire chain.
    public double getTotalExpectedHashes() {
        double totalExpectedHashes = 0;
        for(int i=0; i<blocks.size();i++) {
            totalExpectedHashes += Math.pow((16),getBlock(i).getDifficulty());
        }
        return totalExpectedHashes;
    }

    /*
     * If the chain only contains one block, the genesis block at position 0, this method computes
     * the hash of the block and checks that the hash has the requisite number of leftmost 0's
     * (proof of work) as specified in the difficulty field. It also checks that the chain hash
     * is equal to this computed hash. If either check fails, return false. Otherwise, return true.
     * If the chain has more blocks than one, begin checking all blocks using chainValidation
     * method. If chainValidation method returns a non-negative number continue checking the
     * blocks in the blockchain. When chainValidation method returns -1, then it means the
     * chain validation fails. */
    public boolean isChainValid() {
        if(blocks.size()==1) {
            Block genesis = getBlock(0);
            String genesisHash = genesis.proofOfWork();
            int numberOfZero = 0;
            int difficulty = genesis.getDifficulty();
            char[] charsHash = genesisHash.toCharArray();
            for (int i = 0; i < difficulty; i++) {
                if (charsHash[i] == '0') numberOfZero++;
            }
            return chainHash.equals(genesisHash) && numberOfZero == difficulty;
        } else {
            for(int i=0; i<blocks.size();i++) {
                // checks each node
                int node = chainValidation(i);
                if(node==-1) {
                    // setting index of incorrect node with wrong hash value
                    incorrectNode=i-1;
                    return false;
                }
            }
            return chainHash.equals(getLatestBlock().proofOfWork());
        }
    }

    /*
     * Check hash pointer of each Block and compare with proofOfWork of previous block.
     * If they match and if the proof of work is correct, return block index. else
     * return -1; */
    public int chainValidation(int blockIndex) {
        String prevBlockHash = blockIndex==0?
                "":getBlock(blockIndex-1).proofOfWork();
        String hashPointer = getBlock(blockIndex).getPreviousHash();
        if(prevBlockHash.equals(hashPointer)) {
            if(blockIndex!=0){
                char[] charsHash = prevBlockHash.toCharArray();
                int difficulty = getBlock(blockIndex-1).getDifficulty();
                int numberOfZero = 0;
                for (int i = 0; i < difficulty; i++) {
                    if (charsHash[i] == '0') numberOfZero++;
                }
                if (numberOfZero == difficulty) return blockIndex;
            }
            return blockIndex;
        }
        return -1;
    }

    // checks each block and recomputes proofOfWork for each block and
    // assigns the correct hash pointer in the next block as well as the
    // chain hash using the proofOfWork of the last added block.
    public void repairChain() {
        for(int i=0; i<getChainSize();i++) {
            if(i==0) getBlock(i).setPreviousHash("");
            String correctHash = getBlock(i).proofOfWork();
            if(i+1 < getChainSize())getBlock(i+1).setPreviousHash(correctHash);
            if(i==getChainSize()-1) chainHash=correctHash;
        }
        chainHash=getLatestBlock().proofOfWork();
    }

    // this method parses the json string sent from the client and
    // performs the required operation by parsing through the
    // json object. Further, it creates a new outputPayload
    // json object,converts the json object to string inorder
    // to send back to the requesting client
    public String performOperations(String data) {
        // JSON Parsing
        JsonElement jsonElement = new JsonParser().parse(data);
        // Creating JSON object from parsed string
        JsonObject jsonObject = jsonElement.getAsJsonObject();
        int userInput = jsonObject.get("user_input").getAsInt();
        // JSON object to be returned to client
        JSONObject outputPayload = new JSONObject();
        // load output JSON with user input
        outputPayload.put("user_input",userInput);
        switch (userInput) {
            case 0 -> {
                // loads json with basic blockchain status
                outputPayload.put("chain_size",getChainSize());
                outputPayload.put("latest_difficulty",getLatestBlock().getDifficulty());
                outputPayload.put("total_difficulty",getTotalDifficulty());
                outputPayload.put("hash_per_sec",getHashesPerSecond());
                outputPayload.put("total_exp_hash",getTotalExpectedHashes());
                outputPayload.put("latest_nonce",getLatestBlock().getNonce());
                outputPayload.put("chain_hash",chainHash);
            }
            case 1 -> {
                // load output JSON with computation time after adding new block
                long start = System.currentTimeMillis();
                int difficulty =Integer.parseInt(jsonObject.get("difficulty").getAsString());
                String transaction = jsonObject.get("transaction").getAsString();
                addBlock(new Block(getLatestBlock().getIndex() + 1,
                        new Timestamp(new Date().getTime()), transaction, difficulty));
                long end = System.currentTimeMillis();
                outputPayload.put("computation_time",end-start);
            }
            case 2 -> {
                // performs chain verification, loads output JSON with incorrectNode id
                // and difficulty in case chain verification fails. load output JSON with
                // computation time for the process as well
                long start = System.currentTimeMillis();
                boolean chainVerified = isChainValid();
                outputPayload.put("chain_verified",chainVerified);
                if (!chainVerified) {
                    int difficulty = getBlock(incorrectNode).getDifficulty();
                    outputPayload.put("incorrect_node",incorrectNode);
                    outputPayload.put("difficulty",difficulty);
                }
                long end = System.currentTimeMillis();
                outputPayload.put("computation_time",end-start);
            }
            // loads output json with blockchain content
            case 3 ->  outputPayload.put("output_json",this.toString());
            case 4 -> {
                // updates block data based on block id and transaction passed from
                // the client side and loads output json with the block id and transaction
                int blockId = Integer.parseInt(jsonObject.get("block_id").getAsString());
                String blockTransaction =jsonObject.get("block_transaction").getAsString();
                getBlock(blockId).setData(blockTransaction);
                outputPayload.put("block_id",blockId);
                outputPayload.put("block_transaction",blockTransaction);
            }
            case 5 -> {
                // repairs chain and loads output json with computation time needed
                // for this process
                long start = System.currentTimeMillis();
                repairChain();
                long end = System.currentTimeMillis();
                outputPayload.put("computation_time",end-start);
            }
        }
        // return json string
        return outputPayload.toString();
    }
}
