/*
 * @author: Shivani Poovaiah Ajjikutira
 * Last Modified: 24th October 2021
 *
 * This code forms the client for the interaction with the BlockChain class
 * which serves as the server. The client takes in user input corresponding
 * to the user choice as in Task 0 and based on the user input, takes other
 * necessary details form the user and passed the data in JSON format converted
 * to a string to the server. The GSON library and JSONObject libraries are
 * imported to help form the JSON Object and parse the JSON.
 * The client socket is initialized and forms a
 * connection with the server socket having port number 7777.The client passes
 * the data entered by the user to the server via the socket connection formed.
 * The operation logic happens in the server. The program runs till the user chooses
 * option 6, i.e, exit. When the user enters 6 the connection is terminated,however,
 * the server continues running.
 * */

import com.google.gson.*;
import org.json.simple.JSONObject;

import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.util.Scanner;

public class Client {

    /*
    * Method takes user input and passes data to the getResult method
    * which interacts with the server and returns data as sent from
    * the server. The data is then printed according to needed format
    * using printOutput method. The process continues as long as user
    * does not enter 6, i.e, Exit
    * */
    public static void main(String [] args) {
        try {
            // stores user choice
            int userInput = -1;
            while (userInput != 6) {
                // displays menu options
                displayMenu();
                // Scanner to get user input from console
                Scanner getInput = new Scanner(System.in);
                userInput = Integer.parseInt(getInput.nextLine());
                // gets all necessary data from user and send to getResult method
                // and getResult method returns data sent by server
                String output = getResult(getOperationData(userInput, getInput));
                // to print data sent by server
                printOutput(output);
            }
        } catch (IOException e) {
            System.out.println("IO Exception: "+e.getMessage());
        } catch (Exception e) {
            System.out.println("Exception: "+e.getMessage());
        }
    }

    // this method parses the json string passed to print the output as required
    // by parsing the contents of the json
    // Code from :
    // https://stackoverflow.com/questions/5490789/json-parsing-using-gson-for-java
    private static void printOutput(String output) {
        // JSON parser
        JsonElement jsonElement = new JsonParser().parse(output);
        // creating JSONObject after parsing
        JsonObject jsonObject = jsonElement.getAsJsonObject();
        int userInput = jsonObject.get("user_input").getAsInt();
        switch (userInput) {
            case 0 -> {
                System.out.println("Current size of chain: " + jsonObject.get("chain_size").getAsString());
                System.out.println("Difficulty of most recent block: " + jsonObject.get("latest_difficulty").getAsString());
                System.out.println("Total difficulty for all blocks: " + jsonObject.get("total_difficulty").getAsString());
                System.out.println("Approximate hashes per second on this machine: " + jsonObject.get("hash_per_sec").getAsString());
                System.out.println("Expected total hashes required for the whole chain: " + jsonObject.get("total_exp_hash").getAsString());
                System.out.println("Nonce for most recent block: " + jsonObject.get("latest_nonce").getAsString());
                System.out.println("Chain hash: " + jsonObject.get("chain_hash").getAsString());
            }
            case 1 -> System.out.println("Total execution time to add this block was " + jsonObject.get("computation_time").getAsString() + " milliseconds");
            case 2 -> {
                boolean isChainVerified =jsonObject.get("chain_verified").getAsBoolean();
                if (!isChainVerified) {
                    int incorrectNode = jsonObject.get("incorrect_node").getAsInt();
                    int difficulty = jsonObject.get("difficulty").getAsInt();
                    System.out.printf("..Improper hash on node %d Does not begin with %s\n", incorrectNode, "0".repeat(Math.max(0, difficulty)));
                }
                System.out.println("Chain verification: " + isChainVerified);
                System.out.println("Total execution time required to verify the chain was " + jsonObject.get("computation_time").getAsString() + " milliseconds");
            }
            case 3 -> {
                // Code from https://stackoverflow.com/questions/4105795/pretty-print-json-in-java
                // prettifying JSON to print content one below the other
                Gson gson = new GsonBuilder().setPrettyPrinting().create();
                String prettyJson = gson.toJson(new JsonParser().parse(jsonObject.get("output_json").getAsString()));
                System.out.println(prettyJson);
            }
            case 4 -> {
                int blockId = jsonObject.get("block_id").getAsInt();
                String blockTransaction = jsonObject.get("block_transaction").getAsString();
                System.out.printf("Block %d now holds %s\n", blockId, blockTransaction);
            }
            case 5 -> System.out.printf("Total execution time required to repair the chain was %s milliseconds\n", jsonObject.get("computation_time").getAsString());
        }
    }

    /*
     * This method is used to create connection with the server and
     * pass the data to the server to perform the operation selected
     * by user and returned required data. The client Socket is initialized with
     * source and destination. The BufferedReader in is used to read data sent from the
     * server and the PrintWriter out is used to write into the socket. The payload is written
     * into the socket using the PrintWriter out. On using out.flush() the data in the stream
     * is sent to the server to perform the logic. The reply sent by the server is read using
     * the BufferedReader in and returned to the calling method,i.e., the main method
     * */
    public static String getResult(String payload) throws IOException {
        // Code from EchoClientTCP.java in Project 2
        // client socket declared
        Socket clientSocket = null;
        try {
            // server port number
            int serverPort = 7777;
            // client socket initialized
            clientSocket = new Socket("localhost", serverPort);
            // read data from socket
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            // write data to socket
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));
            // write into socket
            out.println(payload);
            // send data written to server socket
            out.flush();
            // return data to main method
            return in.readLine();
        } catch (SocketException e) {
            // to catch errors when errors occur with the network
            System.out.println("Socket: " + e.getMessage());
        } finally {
            // close socket connection
            if(clientSocket!=null) clientSocket.close();
        }
        return null;
    }

    // this method gets other details from the user based on the menu option selected.
    // The data collected is made into a JSON object and the JSON string is then
    // returned to the calling method, i.e, the getResult method.
    // Code from https://stackoverflow.com/questions/5490789/json-parsing-using-gson-for-java
    private static String getOperationData(int userInput,Scanner getUserInput) {
        // new JSON Object created
        JSONObject json = new JSONObject();
        // add user input to JSON
        json.put("user_input",userInput);
        switch (userInput) {
            case 1 -> {
                System.out.println("Enter difficulty > 0");
                int difficulty = Integer.parseInt(getUserInput.nextLine());
                System.out.println("Enter transaction");
                String transaction = getUserInput.nextLine();
                // add difficulty to JSON object
                json.put("difficulty",difficulty);
                // add transaction to JSON object
                json.put("transaction",transaction);
            }
            case 2 -> System.out.println("Verifying entire chain");
            case 4 -> {
                System.out.println("corrupt the Blockchain\n" +
                        "Enter block ID of block to corrupt");
                int blockId = Integer.parseInt(getUserInput.nextLine());
                System.out.println("Enter new data for block " + blockId);
                String blockTransaction = getUserInput.nextLine();
                // add blockId to JSON object
                json.put("block_id",blockId);
                // add blockTransaction to JSON object
                json.put("block_transaction",blockTransaction);
            }
            case 5 -> System.out.println("Repairing the entire chain");
        }
        // return JSON string
        return json.toString();
    }

    // displays menu options to the user
    public static void displayMenu() {
        System.out.println("""
                0. View basic blockchain status.
                1. Add a transaction to the blockchain.
                2. Verify the blockchain.
                3. View the blockchain.
                4. Corrupt the chain.
                5. Hide the corruption by repairing the chain.
                6. Exit""");
    }
}