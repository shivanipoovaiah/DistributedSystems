/*
 * @author: Shivani Poovaiah Ajjikutira
 * Last Modified: 9th October 2021
 *
 * This code follows Task 4 but the client ID is generated using e+n
 * and the data sent to the server is concatenated with the signature
 * of the data to ensure the data received at the server is the right
 * data. The following code is the client side for a program that returns a
 * number stored against a particular ID or adds/subtracts integers to
 * that integer. The sum/ difference is then stored against the ID.
 * The user id, operation and value(in case of add/subtract) are taken
 * from the user and output is the result of the corresponding operation.
 * The client socket is initialized and forms a connection with the server
 * socket having port number 7777.The client passes the data entered by the
 * user to the server via the socket connection formed. The operation logic
 * happens in the server. The program runs till the user chooses option 4,
 * i.e, exit. When the user enters 4 the connection is terminated,however,
 * the server continues running.
 * */

import java.math.BigInteger;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

public class SigningClientTCP {

    public static void main(String [] args) {
        // stores user choice from menu
        String userChoice;
        try {
            // to read user input from console
            BufferedReader typed = new BufferedReader(new InputStreamReader(System.in));
            // generate public key,private key and store in keys array
            BigInteger [] keys = generateRSAKeys();
            // generate ID using keys and store in id
            String id = generateID(keys);
            /*
             * do-while loop used since we need to run the loop at least once to show the
             * menu and then continues looping until user choose option 4
             * */
            do {
                // displays menu options
                displayMenu();
                // checks if user input it is not null and not option 4, i.e, Exit
                if ((userChoice = typed.readLine()) != null && Integer.parseInt(userChoice)!=4) {
                    // checks if user selects from the available menu options
                    if (Integer.parseInt(userChoice) > 4 || Integer.parseInt(userChoice) < 1) {
                        System.out.println("Please select an integer between 1-4 only");
                    } else { // if user selects a valid menu option performs this block of code

                        // stores integer to be added/subtracted
                        int value = 0;
                        if (Integer.parseInt(userChoice) == 1) {
                            System.out.println("Enter value to add: ");
                            value = Integer.parseInt(typed.readLine());
                        } else if (Integer.parseInt(userChoice) == 2) {
                            System.out.println("Enter value to subtract: ");
                            value = Integer.parseInt(typed.readLine());
                        }
                        /*
                         * The id generated, operation,value and keys generated are sent
                         * to the getResult method. The method returns the result
                         * of the operation which is stored in result variable
                         * */
                        int result = getResult(id, Integer.parseInt(userChoice), value, keys);
                        System.out.println("The result is " + result + ".");
                    }
                }
            } while (userChoice != null && Integer.parseInt(userChoice)!=4);
            // exit loop when user enters 4
            System.out.println("Client side quitting.The remote variable server is still running.");
        } catch (IOException e) {
            // to catch errors when there is an input-output exception
            System.out.println("IO: " + e.getMessage());
        }
    }

    // this method generates id by hashing e+n
    private static String generateID(BigInteger [] keys) {
        //From project 2 ShortMessageSign.java and RSAExample.java code
        BigInteger e = keys[0]; // n is the modulus for both the private and public keys
        BigInteger n = keys[2]; // e is the exponent of the public key
        // concatenating e and n
        String pubKey = e.toString()+n.toString();
        try {
            // converting string to byte array
            byte[] bytesOfPublicKey = pubKey.getBytes(StandardCharsets.UTF_8);
            // Java MessageDigest - to hash strings using SHA-256
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            // stores hashed output e+n
            byte[] hashedOutput = md.digest(bytesOfPublicKey);

            // we only want last 20 bytes of the hash for id.
            // copy last 20 bytes of hashed bytes to idBytes byte array
            byte[] idBytes = new byte[20];
            for(int i=1; i<idBytes.length;i++) {
                idBytes[i] = hashedOutput[hashedOutput.length-(i)];
            }

            // From the hashed idBytes, create a BigInteger
            BigInteger id = new BigInteger(idBytes);

            // return this as a BigInteger string
            return id.toString();
        } catch (NoSuchAlgorithmException i) {
            // to catch error due to MessageDigest
            System.out.println("ID generation: "+ i.getMessage());
        }
        return null;
    }

    // this method generates public and private keys
    private static BigInteger[] generateRSAKeys() {
        // Code from RSAExample.java provided in Project2

        // Each public and private key consists of an exponent and a modulus
        BigInteger n; // n is the modulus for both the private and public keys
        BigInteger e; // e is the exponent of the public key
        BigInteger d; // d is the exponent of the private key

        Random rnd = new Random();

        // Step 1: Generate two large random primes.
        // We use 400 bits here, but best practice for security is 2048 bits.
        // Change 400 to 2048, recompile, and run the program again and you will
        // notice it takes much longer to do the math with that many bits.
        BigInteger p = new BigInteger(400, 100, rnd);
        BigInteger q = new BigInteger(400, 100, rnd);

        // Step 2: Compute n by the equation n = p * q.
        n = p.multiply(q);

        // Step 3: Compute phi(n) = (p-1) * (q-1)
        BigInteger phi = (p.subtract(BigInteger.ONE)).multiply(q.subtract(BigInteger.ONE));

        // Step 4: Select a small odd integer e that is relatively prime to phi(n).
        // By convention the prime 65537 is used as the public exponent.
        e = new BigInteger("65537");

        // Step 5: Compute d as the multiplicative inverse of e modulo phi(n).
        d = e.modInverse(phi);

        // Modulus for both keys
        System.out.printf(" RSA Public key: (e,n) = %d, %d\n",e,n);  // Step 6: (e,n) is the RSA public key
        System.out.printf(" RSA Private key: (d,n) = %d, %d\n",d,n);  // Step 7: (d,n) is the RSA private key
        return new BigInteger [] {e,d,n};
    }

    /*
     * This method is used to create connection with the server and
     * pass the data to the server to perform the addition/subtraction
     * or return the sum stored against the ID generated. The client
     * Socket is initialized with source and destination. The BufferedReader in
     * is used to read data sent from the server and the PrintWriter out is used to
     * write into the socket. The data is concatenated with the signature to form
     * the string payload. The payload is written into the socket using the PrintWriter
     * out. On using out.flush() the data in the stream is sent to the server to perform
     * the logic. The reply sent by the server is read using the BufferedReader in and the
     * result is returned to the calling method,i.e., the main method
     * */
    public static int getResult(String id, int userChoice, int value, BigInteger[] keys) throws IOException {
        // Code from EchoClientTCP.java in Project 2
        // client socket declared
        Socket clientSocket = null;
        try {
            // server port number
            int serverPort = 7777;
            // client socket initialized
            clientSocket = new Socket("localhost", serverPort);
            // read data from socket
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            // write data to socket
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));
            // stores name of operation based on user choice returned
            // by getOperation method
            String operation= getOperation(userChoice);
            String tokens;
            // get operation does not require value
            if (userChoice==3) {
                tokens = id+" "+keys[0]+" "+keys[2]+" "+operation;
            } else {
                tokens = id+" "+keys[0]+" "+keys[2]+" "+operation+" "+value;
            }
            // stores encrypted hashed tokens
            String signature = getSignature(tokens,keys);
            // request string to send to server
            String payload = tokens + " " + signature;
            // write into socket
            out.println(payload);
            // send data written to server socket
            out.flush();
            String data = in.readLine(); // read a line of data from the stream
            return Integer.parseInt(data);
        } catch (SocketException e) {
            // to catch errors when errors occur with the network
            System.out.println("Socket: " + e.getMessage());
        } finally {
            // close socket connection
            if(clientSocket!=null) clientSocket.close();
        }
        return -1;
    }

    // this method creates a signature of tokens using private key
    private static String getSignature(String tokens, BigInteger[] keys) {
        try {
        // Code from Project 2 ShortMessageSign.java

        // converting string to byte array
        byte[] bytesOfMessage = tokens.getBytes(StandardCharsets.UTF_8);
        // Java MessageDigest - to hash strings using SHA-256
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        // byte array that stores hashed output
        byte[] bigDigest = md.digest(bytesOfMessage);

        // add a 0 byte as the most significant byte to keep
        // the value to be signed non-negative.
        byte[] messageDigest = new byte[bigDigest.length+1];
        // set first index of messageDigest to 0
        messageDigest[0] = 0;
        // copy content of bigDigest to messageDigest byte array
        System.arraycopy(bigDigest, 0, messageDigest, 1, messageDigest.length - 1);
        BigInteger d = keys[1]; // d is the exponent of the private key
        BigInteger n = keys[2];  // n is the modulus for both the private and public keys
        // From the digest, create a BigInteger
        BigInteger m = new BigInteger(messageDigest);

        // encrypt the digest with the private key
        BigInteger c = m.modPow(d, n);

        // return this as a big integer string
        return c.toString();
        } catch (NoSuchAlgorithmException e) {
            // to catch error due to MessageDigest
            System.out.println("Signature creation: "+ e.getMessage());
        }
        return null;
    }

    // returns operation name based on the user choice
    private static String getOperation(int userChoice) {
        if(userChoice==1) {
            return "add";
        } else if(userChoice==2) {
            return "subtract";
        } else {
            return "get";
        }
    }

    // displays menu options to the user
    public static void displayMenu() {
        String [] menu = {"Add a value to your sum.","Subtract a value from your sum.",
                "Get your sum","Exit client"};
        for(int i =0; i<menu.length; i++) {
            System.out.printf("%d. %s%n",i+1,menu[i]);
        }
    }
}