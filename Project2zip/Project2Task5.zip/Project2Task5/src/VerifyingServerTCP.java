/*
 * @author: Shivani Poovaiah Ajjikutira
 * Last Modified: 9th October 2021
 *
 * This code follows Task 4 but the client ID is generated using e+n
 * and the data received from the client is concatenated with the signature
 * of the data to ensure the data received is the right data.
 * The following code is the server side for a program that returns a
 * number stored against a particular ID or adds/subtracts integers to
 * that integer. The sum/ difference is then stored against the ID.
 * The operations are performed only if the hashed ID is correct and
 * if the signature is verified. If not an error message is sent back.
 * The user id, operation and value(in case of add/subtract) are sent by
 * the client and output of the corresponding operation is returned to the
 * client. The server socket is initialized and continues to listen to any
 * request sent by client sockets connected to port number 7777.The server
 * receives the data from the client through Scanner "in" via the socket connection
 * formed. The PrintWriter "out" is used to write into the stream and send data
 * back to the requesting client. The performOperations method checks the operation
 * passed and does the required logic. A HashMap is used to store the integer
 * corresponding to each ID. In case of addition and subtraction the HashMap
 * values are updated, in case of get, the value for id as key is returned
 * as result to the client. The server is always running.
 * */

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Scanner;

public class VerifyingServerTCP {
    // maps key-value pair: ID is the key, sum is the value
    static HashMap<BigInteger,Integer> userIdSums = new HashMap<>();
    public static void main(String[] args){
        // Code from EchoServerTCP.java in Project 2
        System.out.println("Server started");
        // client socket declared
        Socket clientSocket = null;
        try{
            int serverPort = 7777; // the server port number

            // Create a new server socket with port number 7777
            ServerSocket listenSocket = new ServerSocket(serverPort);

            // Since server is always running and listens for requests
            while(true){
                /*
                 * Block waiting for a new connection request from a client.
                 * When the request is received, "accept" it, and the rest
                 * the tcp protocol handshake will then take place, making
                 * the socket ready for reading and writing.
                 */
                if(clientSocket==null)
                    clientSocket = listenSocket.accept();
                // If we get here, then we are now connected to a client.

                // Set up "in" to read from the client socket
                Scanner in;
                in = new Scanner(clientSocket.getInputStream());

                // Set up "out" to write to the client socket
                PrintWriter out;
                out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));
                int result;
                // if Scanner in has data from client socket then perform following block
                if(in.hasNextLine()) {
                    // read data from client socket
                    String data = in.nextLine();
                    // split data using " "
                    String[] requestItems = data.split(" ");
                    // boolean storing ID is correct or not
                    boolean rightIDHash = checkIDHash(requestItems[0], requestItems[1], requestItems[2]);
                    // boolean storing signature is verified or not
                    boolean rightSignature = checkSignature(requestItems);
                    System.out.printf("Visitor public key(e,n): (%s,%s)\n", requestItems[1],requestItems[2]);
                    System.out.printf("Signature verified: %s\n", rightSignature);
                    System.out.printf("Operation requested: %s\n", requestItems[3]);
                    // if ID is right and signature is verified perform operation and send result
                    if (rightIDHash && rightSignature) {
                        // result stores sum returned by performOperations method
                        result = performOperations(requestItems);
                        System.out.printf("Value returned: %s\n%n%n", result);
                        // write data to client socket
                        out.println(result);
                    } else {
                        // if either id is incorrect or signature is not verified return the string below
                        System.out.print("Error in request\n");
                        out.println("Error in request\n");
                    }
                    // send data to client socket
                    out.flush();
                } else {
                    // if Scanner in has no data written into it continue listening
                    // wait for new request from client
                    clientSocket = listenSocket.accept();
                }
            }
        }catch (SocketException e) {
            // to catch errors when errors occur with the network
            System.out.println("Socket: " + e.getMessage());
        }catch (IOException e){
            // to catch errors when there is an input-output exception
            System.out.println("IO: " + e.getMessage());
        } catch (Exception e) {
            // catch any other exception
            System.out.println("Exception: " + e.getMessage());
        }
    }

    // method to verify the signature
    private static boolean checkSignature(String[] requestItems) throws Exception {

        // Code from Project 2 ShortMessageVerify.java
        String signature = requestItems[requestItems.length-1]; // signature received
        BigInteger e = new BigInteger(requestItems[1]); // e is the exponent of the public key
        BigInteger n = new BigInteger(requestItems[2]); // n is the modulus for both the private and public keys
        StringBuilder tokens= new StringBuilder();
        // generate the initial data without the signature concatenated
        for(int i=0; i<requestItems.length-1;i++) {
            tokens.append(requestItems[i]).append(" ");
        }
        // convert tokens to byte array
        byte[] bytesOfMessageToCheck = tokens.toString().trim().getBytes(StandardCharsets.UTF_8);
        // clearing StringBuilder
        tokens.setLength(0);

        // compute the digest of the bytesOfMessageToCheck byte array with SHA-256
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] messageToCheckDigest = md.digest(bytesOfMessageToCheck);

        // messageToCheckDigest is a full SHA-256 digest
        // Add a zero byte since signature is always for positive value
        byte[] newMessage = new byte[messageToCheckDigest.length+1];
        newMessage[0] = 0;
        System.arraycopy(messageToCheckDigest, 0, newMessage, 1, newMessage.length - 1);

        // converting byte array to BigInteger
        BigInteger bigIntegerToCheck = new BigInteger(newMessage);


        // Take the encrypted hashed string and make it a big integer
        BigInteger encryptedHash = new BigInteger(signature);
        // Decrypt it using public key
        BigInteger decryptedHash = encryptedHash.modPow(e, n);
        // return how the two compare
        return bigIntegerToCheck.compareTo(decryptedHash) == 0;
    }

    // method to check the id
    private static boolean checkIDHash(String id, String e, String n) {
        // concatenating e and n
        String pubKey = e+n;
        try {
            //From project 2 ShortMessageSign.java and RSAExample.java code

            // Java MessageDigest - to hash strings using SHA-256
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            // converting string to byte array and stores hashed output e+n in hashedPublicKey
            byte[] hashedPublicKey = md.digest(pubKey.getBytes(StandardCharsets.UTF_8));

            // we only want last 20 bytes of the hash for id.
            // copy last 20 bytes of hashed bytes to idBytes byte array
            byte[] hashedPubKey = new byte[20];
            for (int i = 1; i < hashedPubKey.length; i++) {
                hashedPubKey[i] = hashedPublicKey[hashedPublicKey.length - (i)];
            }
            // BigInteger having 20 bytes of hashed (e+n)
            BigInteger computedId = new BigInteger(hashedPubKey);
            // BigInteger having id
            BigInteger bigId = new BigInteger(id);
            // compare computed id and id
            if(bigId.equals(computedId)) return true;
        } catch (NoSuchAlgorithmException i) {
            // to catch error due to MessageDigest
            System.out.println("ID generation: "+ i.getMessage());
        }
        return false;
    }

    /*
     * This method performs all the logical operation based on the
     * operation selected by the user as sent by the client in the
     * request. The userIdSums HashMap is used to store the key-value
     * pairs of id and sum. If a particular id does not exist and the
     * user selects "get" operation, put id and value 0 to the hashmap.
     * For any other operation, put id and the value sent from client.
     * If the id is present, then return the value stored against id in
     * the Hashmap in case the operation is "get". In case of "add"/"subtract"
     * operations add/subtract the value with the existing value in the
     * HashMap, update the value with the new sum/difference and return
     * the new sum/difference
     * */
    public static int performOperations(String [] requestItems) {
        BigInteger id = new BigInteger(requestItems[0]);
        String operation = requestItems[3];
        // if id not present and operation is "get"
        if(userIdSums.get(id) == null && operation.equals("get")) {
            userIdSums.put(id,0);
        } else if(userIdSums.get(id) == null && !operation.equals("get")) {
            userIdSums.put(id,Integer.parseInt(requestItems[4]));
        }
        // if id present
        else {
            if(operation.equals("add")) {
                int value = Integer.parseInt(requestItems[4]);
                int newTotal = userIdSums.get(id)+value;
                // update new total
                userIdSums.put(id,newTotal);
            } else if(operation.equals("subtract")) {
                int value = Integer.parseInt(requestItems[4]);
                int newTotal = userIdSums.get(id)-value;
                // update new total
                userIdSums.put(id,newTotal);
            }
        }
        // return latest value stores against id
        return userIdSums.get(id);
    }
}
