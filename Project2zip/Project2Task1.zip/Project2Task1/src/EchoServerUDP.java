import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

/*
 * @author: Shivani Poovaiah Ajjikutira
 * Last Modified: 8th October 2021
 *
 * The following code is written for UDP Server. The code creates a
 * socket and with port number 6789. It receives a DatagramPacket from
 * the client which established a connection with this server.
 * The bytes of request are copied into a byte array of correct size based
 * on the request data. The correct sized byte array is then converted into a
 * string and displayed to the user as "Echoing". This process continues as long as
 * the user does not send message "halt!". When the user, sends "halt!" the socket
 * is closed and connection is terminated.
 * */
public class EchoServerUDP{
    public static void main(String[] args){
        // Project 2 Code from EchoServerUDP.java
        System.out.println("The server is running.");
        // Server DatagramSocket to receive data from the client declared
        DatagramSocket aSocket = null;
        // default buffer array to initialize DatagramPacket storing client request data
        byte[] buffer = new byte[1000];
        try{
            // Server socket initialized with server port number
            aSocket = new DatagramSocket(6789);
            // DatagramPacket initialized with default buffer array and size of buffer array to receive
            // data from client socket
            DatagramPacket request = new DatagramPacket(buffer, buffer.length);
            // to ensure the client is always running
            while(true){
                // data packet received from client socket connected to server port 6789
                aSocket.receive(request);
                // prints client's port number
                System.out.println("Sending data to port number: " + request.getPort());
                // DatagramPacket initialized with request data, length of request data, client IP address and client port number
                DatagramPacket reply = new DatagramPacket(request.getData(),
                        request.getLength(), request.getAddress(), request.getPort());
                // byte array of correct size based on request
                byte[] requestBytes = new byte[request.getLength()];
                // copy data from request DatagramPacket to correct sized array
                System.arraycopy(request.getData(), 0, requestBytes, 0, request.getLength());
                // convert request data in bytes to string
                String requestString = new String(requestBytes);
                // print request string
                System.out.println("Echoing: "+requestString);
                // reply DatagramPacket sent through DataSocket to client
                aSocket.send(reply);
                // if request string is "halt!" close the connection.
                if(requestString.equals("halt!")) {
                    System.out.println("Server side quitting.");
                    // terminate socket
                    aSocket.close();
                }
            }
        }catch (SocketException e) {
            // to catch errors when errors occur with the network
            System.out.println("Socket: " + e.getMessage());
        }catch (IOException e){
            // to catch errors when there is an input-output exception
            System.out.println("IO: " + e.getMessage());
        }finally {
            // closing the socket if not closed earlier
            if(aSocket != null) aSocket.close();
        }
    }
}
