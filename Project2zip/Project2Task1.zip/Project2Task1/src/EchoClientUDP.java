/*
* @author: Shivani Poovaiah Ajjikutira
* Last Modified: 8th October 2021
*
* The following code is written for UDP Client. The code creates a
* socket and established connection with the server. It accepts
* string input from user, converts the string into bytes. The bytes
* of data are then added to a DatagramPacket and sent to the server. The
* server sends a response as a DatagramPacket which has bytes of reply.
* The bytes of reply are copied into a byte array of correct size based
* on the reply data. The correct sized byte array is then converted into a
* string and displayed to the user. This process continues as long as
* the user does not enter the message "halt!". When the user, enters
* "halt!" the socket is closed and connection is terminated.
* */

import java.net.*;
import java.io.*;

public class EchoClientUDP{
    public static void main(String [] args){
        // Project 2 Code from EchoClientUDP.java
        System.out.println("The client is running.");
        // Client DatagramSocket to send data to server declared
        DatagramSocket aSocket = null;
        try {
            // gets IP address of local host
            InetAddress aHost = InetAddress.getByName("localhost");
            // server port number
            int serverPort = 6789;
            // Client DatagramSocket to send data to server declared
            aSocket = new DatagramSocket();
            String nextLine;
            String checkString;
            // reads user input from console
            BufferedReader typed = new BufferedReader(new InputStreamReader(System.in));
            while (typed!=null && (nextLine = typed.readLine()) != null) {
                // converts user input string to byte array
                byte [] m = nextLine.getBytes();
                // DatagramPacket initialized with message bytes, length of array, host IP address and server port number
                DatagramPacket request = new DatagramPacket(m,  m.length, aHost, serverPort);
                // data packet sent through DataSocket to server
                aSocket.send(request);
                // default buffer array to initialize DatagramPacket storing server response data
                byte[] buffer = new byte[1000];
                // user input string
                checkString = new String(m);
                /*
                * If user enters "halt!" close the Client DatagramSocket else receive
                * reply bytes from server. Check the length of the reply and create
                * a new byte array of required size. Convert this new byte array into
                * a string and display to the user.
                * */
                if(!checkString.equals("halt!")) {
                    // DatagramPacket initialized with buffer array of size 1000 bytes
                    DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
                    // data packet received from server
                    aSocket.receive(reply);
                    // byte array of correct size based on reply
                    byte[] replyBytes = new byte[reply.getLength()];
                    // copy data from DatagramPacket to correct sized array
                    for (int i = 0; i < reply.getLength(); i++) {
                        replyBytes[i] = reply.getData()[i];
                    }
                    // convert reply data in bytes to string
                    String replyString = new String(replyBytes);
                    // print reply on console
                    System.out.println("\rReply: " + replyString);
                } else {
                    System.out.println("Client side quitting.");
                    typed = null;
                    // close Client DatagramSocket and end connection with server
                    aSocket.close();
                }
            }

        }catch (SocketException e) {
            // to catch errors when errors occur with the network
            System.out.println("Socket: " + e.getMessage());
        }catch (IOException e){
            // to catch errors when there is an input-output exception
            System.out.println("IO: " + e.getMessage());
        }finally {
            // closing the socket if not closed earlier
            if(aSocket != null) aSocket.close();
        }
    }
}