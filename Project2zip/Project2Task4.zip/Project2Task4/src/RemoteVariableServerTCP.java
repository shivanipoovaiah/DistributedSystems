/*
 * @author: Shivani Poovaiah Ajjikutira
 * Last Modified: 9th October 2021
 *
 * This code follows Task 3 but uses TCP instead of UDP for the data
 * transmission between the client and server.
 * The following code is the server side for a program that returns a
 * number stored against a particular ID or adds/subtracts integers to
 * that integer. The sum/ difference is then stored against the ID.
 * The user id, operation and value(in case of add/subtract) are sent by
 * the client and output of the corresponding operation is returned to the
 * client. The server socket is initialized and continues to listen to any
 * request sent by client sockets connected to port number 7777.The server
 * receives the data from the client through Scanner "in" via the socket connection
 * formed. The PrintWriter "out" is used to write into the stream and send data
 * back to the requesting client. The performOperations method checks the operation
 * passed and does the required logic. A HashMap is used to store the integer
 * corresponding to each ID. In case of addition and subtraction the HashMap
 * values are updated, in case of get, the value for id as key is returned
 * as result to the client. The server is always running.
 * */

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Scanner;

public class RemoteVariableServerTCP {
    // maps key-value pair: ID is the key, sum is the value
    static HashMap<Integer,Integer> userIdSums = new HashMap<>();
    public static void main(String[] args){
        // Code from EchoServerTCP.java in Project 2
        System.out.println("Server started");
        // client socket declared
        Socket clientSocket = null;
        try{
            int serverPort = 7777; // the server port number

            // Create a new server socket with port number 7777
            ServerSocket listenSocket = new ServerSocket(serverPort);

            // Since server is always running and listens for requests
            while(true){
                /*
                 * Block waiting for a new connection request from a client.
                 * When the request is received, "accept" it, and the rest
                 * the tcp protocol handshake will then take place, making
                 * the socket ready for reading and writing.
                 */
                if(clientSocket==null || clientSocket.getInputStream().read() == -1)
                    clientSocket = listenSocket.accept();
                // If we get here, then we are now connected to a client.

                // Set up "in" to read from the client socket
                Scanner in;
                in = new Scanner(clientSocket.getInputStream());

                // Set up "out" to write to the client socket
                PrintWriter out;
                out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));
                int result;
                // read from client socket
                String data = in.nextLine();
                // split using " "
                String [] requestItems = data.split(" ");
                // result stores sum returned by performOperations method
                result = performOperations(requestItems);
                System.out.printf("Client ID:%s,Operation:%s,Returning sum of %d\n%n",requestItems[0],requestItems[1],result);
                // write to client socket
                out.println(result);
                // send data written to client socket
                out.flush();
            }
        } catch (SocketException e) {
            // to catch errors when errors occur with the network
            System.out.println("Socket: " + e.getMessage());
        }catch (IOException e){
            // to catch errors when there is an input-output exception
            System.out.println("IO: " + e.getMessage());
        }
    }

    /*
     * This method performs all the logical operation based on the
     * operation selected by the user as sent by the client in the
     * request. The userIdSums HashMap is used to store the key-value
     * pairs of id and sum. If a particular id does not exist and the
     * user selects "get" operation, put id and value 0 to the hashmap.
     * For any other operation, put id and the value sent from client.
     * If the id is present, then return the value stored against id in
     * the Hashmap in case the operation is "get". In case of "add"/"subtract"
     * operations add/subtract the value with the existing value in the
     * HashMap, update the value with the new sum/difference and return
     * the new sum/difference
     * */
    public static int performOperations(String [] requestItems) {
        int id = Integer.parseInt(requestItems[0]);
        String operation = requestItems[1];
        // if id not present and operation is "get"
        if(userIdSums.get(id) == null && operation.equals("get")) {
            userIdSums.put(id,0);
        } else if(userIdSums.get(id) == null && !operation.equals("get")) {
            userIdSums.put(id,Integer.parseInt(requestItems[2]));
        }
        // if id present
        else {
            if(operation.equals("add")) {
                int value = Integer.parseInt(requestItems[2]);
                int newTotal = userIdSums.get(id)+value;
                // update new total
                userIdSums.put(id,newTotal);
            } else if(operation.equals("subtract")) {
                int value = Integer.parseInt(requestItems[2]);
                int newTotal = userIdSums.get(id)-value;
                // update new total
                userIdSums.put(id,newTotal);
            }
        }
        // return latest value stores against id
        return userIdSums.get(id);
    }
}
