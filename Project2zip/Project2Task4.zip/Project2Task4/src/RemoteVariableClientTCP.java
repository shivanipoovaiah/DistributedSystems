/*
 * @author: Shivani Poovaiah Ajjikutira
 * Last Modified: 9th October 2021
 *
 * This code follows Task 3 but uses TCP instead of UDP for the data
 * transmission between the client and server.
 * The following code is the client side for a program that returns a
 * number stored against a particular ID or adds/subtracts integers to
 * that integer. The sum/ difference is then stored against the ID.
 * The user id, operation and value(in case of add/subtract) are taken
 * from the user and output is the result of the corresponding operation.
 * The client socket is initialized and forms a connection with the server
 * socket having port number 7777.The client passes the data entered by the
 * user to the server via the socket connection formed. The operation logic
 * happens in the server. The program runs till the user chooses option 4,
 * i.e, exit. When the user enters 4 the connection is terminated,however,
 * the server continues running.
 * */

import java.net.*;
import java.io.*;

public class RemoteVariableClientTCP {

    public static void main(String [] args){
        // stores user choice from menu
        String userChoice = null;
        // to read user input from console
        BufferedReader typed = new BufferedReader(new InputStreamReader(System.in));
        /*
         * do-while loop used since we need to run the loop at least once to show the
         * menu and then continues looping until user choose option 4
         * */
        do {
            // displays menu options
            displayMenu();
            try {
                // checks if user input it is not null and not option 4, i.e, Exit
                if ((userChoice = typed.readLine()) != null && Integer.parseInt(userChoice)!=4) {
                    // checks if user selects from the available menu options
                    if (Integer.parseInt(userChoice) > 4 || Integer.parseInt(userChoice) < 1) {
                        System.out.println("Please select an integer between 1-4 only");
                    } else { // if user selects a valid menu option performs this block of code

                        // stores integer to be added/subtracted
                        int value = 0;
                        if (Integer.parseInt(userChoice) == 1) {
                            System.out.println("Enter value to add: ");
                            value = Integer.parseInt(typed.readLine());
                        } else if (Integer.parseInt(userChoice) == 2) {
                            System.out.println("Enter value to subtract: ");
                            value = Integer.parseInt(typed.readLine());
                        }
                        System.out.println("Enter your ID: ");
                        // stores ID
                        int id = Integer.parseInt(typed.readLine());
                        // checks if ID range is valid else throws exception and displays
                        // message to user
                        if (id > 1999 || id < 1000) {
                            throw new IDOutOfRangeException("ID out of range. Valid range: 1000-1999");
                        }
                        /*
                         * The id, operation and value entered by the user is sent
                         * to the getResult method. The method returns the result
                         * of the operation which is stored in result variable
                         * */
                        int result = getResult(id, Integer.parseInt(userChoice), value);
                        System.out.println("The result is " + result + ".");
                    }
                }
            } catch (IDOutOfRangeException e) {
                // To catch incorrect range of ID
                System.out.println(e.getMessage());
            } catch (IOException e) {
                // to catch errors when there is an input-output exception
                System.out.println("IO: " + e.getMessage());
            }
        } while (userChoice!=null && !userChoice.equals("4"));
        // exit loop when user enters 4
        System.out.println("Client side quitting.The remote variable server is still running.");
    }

    /*
     * This method is used to create connection with the server and
     * pass the data to the server to perform the addition/subtraction
     * or return the sum stored against the ID entered by the user. The client
     * Socket is initialized with source and destination. The BufferedReader in
     * is used to read data sent from the server and the PrintWriter out is used to
     * write into the socket. The payload is written into the socket using the PrintWriter
     * out. On using out.flush() the data in the stream is sent to the server to perform
     * the logic. The reply sent by the server is read using the BufferedReader in and the
     * result is returned to the calling method,i.e., the main method
     * */
    public static int getResult(int id, int userChoice, int value) throws IOException {
        // Code from EchoClientTCP.java in Project 2
        // client socket declared
        Socket clientSocket = null;
        try {
            // server port number
            int serverPort = 7777;
            // client socket initialized
            clientSocket = new Socket("localhost", serverPort);
            // read data from socket
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            // write data to socket
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));
            // stores name of operation based on user choice returned
            // by getOperation method
            String operation= getOperation(userChoice);
            // stores request string to be sent to server
            String payload;
            // get operation does not require value
            if (userChoice==3) {
                payload =  id + " " + operation;
            } else {
                payload =  id + " " + operation + " " + value;
            }
            // write into socket
            out.println(payload);
            // send data written to server socket
            out.flush();
            String data = in.readLine(); // read a line of data from the stream
            return Integer.parseInt(data);
        } catch (SocketException e) {
            // to catch errors when errors occur with the network
            System.out.println("Socket: " + e.getMessage());
        } finally {
            // close socket connection
            if(clientSocket!=null) clientSocket.close();
        }
        return -1;
    }

    // returns operation name based on the user choice
    private static String getOperation(int userChoice) {
        if(userChoice==1) {
            return "add";
        } else if(userChoice==2) {
            return "subtract";
        } else {
            return "get";
        }
    }

    // displays menu options to the user
    public static void displayMenu() {
        String [] menu = {"Add a value to your sum.","Subtract a value from your sum.",
                "Get your sum","Exit client"};
        for(int i =0; i<menu.length; i++) {
            System.out.printf("%d. %s%n",i+1,menu[i]);
        }
    }

    // New Exception created to track ID which is out of range
    public static class IDOutOfRangeException extends Exception {

        public IDOutOfRangeException(String message) {
            super(message);
        }
    }


}