/*
 * @author: Shivani Poovaiah Ajjikutira
 * Last Modified: 8th October 2021
 *
 * The following code is the client side for a program that adds numbers.
 * The code takes integer values from the user and output is the sum of
 * the integers. The client socket is initialized and forms a connection
 * with the server socket having port number 6789.The client passes the
 * integers to the server through DatagramPacket.The addition logic happens
 * in the server. The program runs till the user enters "halt!". When the
 * user enters "halt!" the connection is terminated, however, the server
 * continues to be on.
 * */

import java.net.*;
import java.io.*;

public class AddingClientUDP{
    public static void main(String [] args){
        // Project 2 Code from EchoClientUDP.java
        System.out.println("The client is running.");
        String nextLine;
        try{
            // reads user input from console
            BufferedReader typed = new BufferedReader(new InputStreamReader(System.in));
            // keep looping as long as user does not enter "halt!"
            while ((nextLine = typed.readLine()) != null && !nextLine.equals("halt!")) {
                try{
                    /*
                    * The user input string is converted into an integer using parseInt
                    * and passed as a parameter to add method. The add method returns
                    * the sum which is stored in newSum.
                    * */
                    int newSum = add(Integer.parseInt(nextLine));
                    System.out.println("The server returned " + newSum+".");
                } catch (NumberFormatException e) {
                    // shows exception message if user enters non-integer values
                    System.out.println("Incorrect input. Enter integers only");
                }
            }
            System.out.println("Client side quitting.");
        }catch (IOException e){
            // to catch errors when there is an input-output exception
            System.out.println("IO: " + e.getMessage());
        }
    }

    /*
    * This method is used to create connection with the server and
    * pass the data to the server to perform the addition. The client
    * Socket is initialized. The DatagramPacket used for data transmission
    * is initialized with the user input in bytes, the length of the byte
    * array, the host IP address and the server port number. The reply
    * sent by the server is added into an array of correct size based
    * on the reply string and returned to the calling method, i.e., the
    * main method
    * */
    public static int add(int i) throws IOException {
        DatagramSocket aSocket = null;
        try {
            // Project 2 Code from EchoClientUDP.java

            // gets IP address of local host
            InetAddress aHost = InetAddress.getByName("localhost");
            // server port number
            int serverPort = 6789;
            // 4-byte byte array
            byte [] message = new byte[4];
            // converting integer into 4-byte byte array
            for(int j=0;j<message.length;j++) {
                if(j < Integer.toString(i).getBytes().length) {
                    message[j] = Integer.toString(i).getBytes()[j];
                }
                else message[j] = 0;
            }
            // client socket initialized
            aSocket = new DatagramSocket();
            // client DatagramPacket initialized
            DatagramPacket request = new DatagramPacket(message, message.length, aHost, serverPort);
            // request sent to server through client socket
            aSocket.send(request);
            // default byte array to store server response data, initialized DatagramPacket
            byte[] buffer = new byte[1000];
            // DatagramPacket to store server reply
            DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
            // reply from server received at client socket
            aSocket.receive(reply);
            // byte array of correct size based on reply string length
            byte[] replyBytes = new byte[reply.getLength()];
            // copy contents of reply DatagramPacket to replyBytes - syntax: IntelliJ suggestion
            System.arraycopy(reply.getData(), 0, replyBytes, 0, reply.getLength());
            // convert reply bytes to string
            String replyString = new String(replyBytes);
            // return reply string to calling method
            return Integer.parseInt(replyString);
        } catch (SocketException e) {
            // to catch errors when errors occur with the network
            System.out.println("Socket: " + e.getMessage());
        } finally {
            // closing the socket if not closed earlier
            if(aSocket!=null) aSocket.close();
        }
        return -1;
    }
}