/*
 * @author: Shivani Poovaiah Ajjikutira
 * Last Modified: 8th October 2021
 *
 * The following code is the server side for a program that adds numbers.
 * The server socket is initialized with port number 6789 and forms a
 * connection with any client socket trying to connect to port number 6789.
 * The client passes the integers to the server through DatagramPacket.
 * The addition logic happens in the server in the add method. The program
 * on the server side keeps running always.
 * */

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class AddingServletUDP {
    public static void main(String[] args){
        System.out.println("Server started");
        // to store the sum
        int sum=0;
        // Server socket
        DatagramSocket aSocket = null;
        // default byte array to store client request data in DatagramPacket
        byte[] buffer = new byte[1000];
        try{
            // Server socket initialized with port number 6789
            aSocket = new DatagramSocket(6789);
            // DatagramPacket initialized with default array and its length
            DatagramPacket request = new DatagramPacket(buffer, buffer.length);
            // since Server is always up and running
            while(true){
                // Server receives requests sent from client socket connected
                // to port number 6789
                aSocket.receive(request);
                // DatagramPacket to send reply data back to the client
                DatagramPacket reply = new DatagramPacket(request.getData(),
                        request.getLength(), request.getAddress(), request.getPort());
                // byte-array of correct size to store request data
                byte[] requestBytes = new byte[request.getLength()];
                // copy data from DatagramPacket to correct sized array  - syntax: IntelliJ suggestion
                System.arraycopy(request.getData(), 0, requestBytes, 0, request.getLength());
                // convert request bytes to string
                String requestString = new String(requestBytes);
                /*
                * Parse request string to form an integer and send it to add
                * method along with the sum to perform addition. The result returned
                * is stored in the sum variable. */
                sum = add(Integer.parseInt(requestString.trim()), sum);
                // convert sum to byte array
                byte [] replyBytes = Integer.toString(sum).getBytes();
                // load the response DatagramPacket with the response byte array
                reply.setData(replyBytes);
                System.out.printf("Returning sum of %d to client\n%n",sum);
                // send reply DatagramPacket back to the client socket that sent the request
                aSocket.send(reply);
            }
        }catch (SocketException e) {
            // to catch errors when errors occur with the network
            System.out.println("Socket: " + e.getMessage());
        }catch (IOException e){
            // to catch errors when there is an input-output exception
            System.out.println("IO: " + e.getMessage());
        }
    }

    /*
    * This method performs addition of two integers and
    * returns the sum of the two integers*/
    public static int add(int i, int j) {
        System.out.printf("Adding: %d to %d%n",i,j);
        return i+j;
    }
}
